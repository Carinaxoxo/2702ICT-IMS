let API_KEY = "api_key=dc140afe3fd3a251c2fdf9dcd835be5c";
let interestingStr = "https://api.flickr.com/services/rest/?method=flickr.interestingness.getList&per_page=15&format=json&nojsoncallback=1&" + API_KEY;
let photos = []; // for storing photos
let viewedps = []; // for storing viewed photos
let indexs = []; // for storing photos in the homespage
let nrequest;
let nrecived;

$(document).ready(function() {
    index(interestingStr); // get some photos in the homepage
    locations(); // call the function named location
    search(); // call search funtion

    $('#modal-close').click(function() { // to close the full photo page
        $('#modal-container').css('display', 'none');
        $('#modal-content').attr('src', ''); // clear the src attribute
    });

    $('#modal-left').click(function() { // get to last photo
        $("#thumbnails figure").eq(indexs[indexs.length - 1] - 1).click();
    });

    $('#modal-right').click(function() { // get to next photo
        $("#thumbnails figure").eq(indexs[indexs.length - 1] + 1).click();
    });
});

function index(interestingStr) {
    $.get(interestingStr, function(data) {
        fetchPhoto(data);
    });
} //get some photos to display on the homepage

function fetchPhoto(data) {
    nrequest = data.photos.photo.length; // to make sure there is no crash
    nrecived = 0;
    photos = []; // clear the history
    for (let i = 0; i < data.photos.photo.length; i++) { //get all the fetched photo and display them
        let t = "no title";
        if (data.photos.photo[i].title) { // if there is no title, use another string
            t = data.photos.photo[i].title
        }
        let photoObj = {
            id: data.photos.photo[i].id,
            title: t
        }; //get photo ID and title
        photos.push(photoObj); // add this photo to photos
        getSizes(photoObj); // get the size of this photo
    }
}

function getSizes(photoObj) {
    let getSizesStr = "https://api.flickr.com/services/rest/?method=flickr.photos.getSizes&format=json&nojsoncallback=1&" + API_KEY + "&photo_id=" + photoObj.id;
    $.get(getSizesStr, function(data) {
        nrecived++;
        if (data.sizes.size[3].source) {
            photoObj.file = data.sizes.size[3].source; // get the small size
        } else {
            photoObj.file = data.sizes.size[0].source; //If “Small” size does not exist, use the smallest photo
        }
        if (data.sizes.size[8].source) {
            photoObj.full = data.sizes.size[8].source; // The “Large” size photo should be used for full-size display
        } else {
            photoObj.full = data.sizes.size[data.sizes.size.length - 1].source; // If “Large” size does not exist, use the largest available
        }
        if (nrecived == nrequest) { // make sure nothing's searched and there is no crash
            display(photos);
        }
    });
}

function display(photos) {
    let htmlStr = "";
    $("#thumbnails").html(htmlStr); // clear the home page before displaying results
    for (let i = 0; i < photos.length; i++) {
        htmlStr += `<figure data-full="${photos[i].full}"><a href="${photos[i].file}"></a><img src="${photos[i].file}" width=200 height=200 alt="image"><figcaption>${photos[i].title}</figcaption></figure>`;
    } // add the photos to screen
    $("#thumbnails").html(htmlStr); // apply the add

    $('figure').each(function(index) { // when a figure is clicked, execute this function
        let caption = ""; // prepare for getting caption
        if (photos[index].title) { // if there is a title
            caption = `${photos[index].title}`; // make it in caption
        } else { // if no
            caption = "no title"; // use "no title" instead
        }
        let pics = $("#thumbnails").html();
        $(this).click(function() { // when a figure is clicked, execute this function
            $('#modal-container').css('display', 'block'); // make the full page displayed
            $('#modal-content').attr('src', $(this).attr('data-full')); // display the full photo
            $("#modal-caption").html(caption); // apply the caption

            let getlocationStr = "https://api.flickr.com/services/rest/?method=flickr.photos.geo.getLocation&per_page=15&format=json&nojsoncallback=1&" + API_KEY + "&photo_id=" + photos[index].id; // get the location where this photo was taken
            $.get(getlocationStr, function(data) {
                if (data.message) { // if the message is not empty 
                    $("#photo-location").html("this photo has no location information"); // that means there is no location info
                } else {
                    $("#photo-location").html(data.photo.location.country._content.replace(/['"]+/g, '')); // remove the double quotes
                    $("#photo-location").click(function() {
                        let locationLink = "https://api.flickr.com/services/rest/?method=flickr.photos.search&per_page=15&format=json&nojsoncallback=1&" + API_KEY + "&text=" + data.photo.location.country._content.replace(/['"]+/g, ''); // search the pictures of this location
                        $.get(locationLink, function(data) {
                            fetchPhoto(data); // display them
                        });
                        $('#modal-container').css('display', 'none'); // when the location is clicked, that means the full photo is closed
                        $('#modal-content').attr('src', ''); // closed 
                    });
                }
            });
            if (viewedps.length < 5) { // if there are less than 5 photos in history
                let content = $(this).clone().get(0).innerHTML; // get the content of clicked photos
                let df = $(this).attr('data-full'); // get the resource
                let pic = `<figure data-full="${df}">${content}</figure>`; // add an element to the history
                let i = viewedps.indexOf(pic); // search if this photo is in the history
                if (i >= 0) {
                    viewedps.splice(i, 1); // if yes, delete the old one and display it at the top
                    viewedps.unshift(pic);
                } else {
                    viewedps.unshift(pic); // if no, add and display
                }
            } else { // if there are 5 photos in the history, detele the last one then execute the same adding method
                viewedps.pop();
                let content = $(this).clone().get(0).innerHTML;
                let df = $(this).attr('data-full');
                let pic = `<figure data-full="${df}">${content}</figure>`;
                let i = viewedps.indexOf(pic);
                if (i >= 0) {
                    viewedps.splice(i, 1);
                    viewedps.unshift(pic);
                } else {
                    viewedps.unshift(pic);
                }
            }
            let content = "";
            for (let i = 0; i < viewedps.length; i ++) { // read the content of every element
                content += viewedps[i];
            }
            $("#viewedpics").html(content); //display the photos
            indexs.push(index); // if clicked, put it in a array for searching
        });
    });
}

function locations() {
    let fig = $("figure").html(); // get the html content of figures
    $("#baritems p").click(function() { // if clicked, execute this function
        let location = $(this).text(); // get the location
        let htmlStr = "";
        $("#thumbnails").html(htmlStr); // clear the screem
        let locationStr = "https://api.flickr.com/services/rest/?method=flickr.photos.search&per_page=15&format=json&nojsoncallback=1&" + API_KEY + "&text=" + location; // search photos of this location 
        $.get(locationStr, function(data) {
            fetchPhoto(data); //display them
        });
    });
}

function search() {
    let fig = $("figure").html(); // get the html content of figures
    $("#search-btn").click(function() { // if search  button is clicked, execute this function
        let input = $("#search-input").val(); // get the value in the search field
        let htmlStr = "";
        $("#thumbnails").html(htmlStr); // clear the screen
        let resultStr = "https://api.flickr.com/services/rest/?method=flickr.photos.search&per_page=15&format=json&nojsoncallback=1&" + API_KEY + "&text=" + input; // search the content of input
        $.get(resultStr, function(data) { // get photos and display them
            nrequest = data.photos.photo.length;
            nrecived = 0;
            photos = [];
            for (let i = 0; i < data.photos.photo.length; i++) {
                let photoObj = {
                    id: data.photos.photo[i].id,
                    title: data.photos.photo[i].title
                };
                photos.push(photoObj);
                getSizes(photoObj);
            }
        });
    });
}