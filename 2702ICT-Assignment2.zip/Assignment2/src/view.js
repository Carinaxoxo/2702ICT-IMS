import $ from "jquery";
import  thumbs from "./templates/thumbnails.handlebars";
import  alerts from "./templates/alert.handlebars";
import alertphoto from "./assets/alertimg.png";
import  {AddLocMarkers} from "./google.js";


// this is used to display photos
export function displayIntres(photosArr){
    let data={photos: photosArr};
    let template = thumbs(data); // translate data to html language
    $("#interesting").html(template); // insert the reabable data
}

// this function will rearrange data then pass it to google.js to add markers
export function displayInfo(infos) {
    let data={locations: infos[0],
              events: infos[1],
              likes: infos[2]
    };
    
    if (data.events.length !==0 || data.likes.length !== 0) { // if there is enough information to be retrieved, hide the alert photo
        $("#alert").css('display', 'none');
    } 
    AddLocMarkers(data); // pass data to add markers
}