import $ from "jquery";
let API_KEY = "api_key=dc140afe3fd3a251c2fdf9dcd835be5c";
let interestingStr = "https://api.flickr.com/services/rest/?method=flickr.interestingness.getList&per_page=20&format=json&nojsoncallback=1&" + API_KEY;
let photos = [];
let results = [];
let indexs = [];
let nrequest;
let nrecived;
let ready_cd;

// fetch interesting photos from flickr
export function getInteresting(ready){
    ready_cd = ready; //pass the function which is used to pass data to view
    $.get(interestingStr, function(data){ // fetch photo data
       fetchPhoto(data); //pass it
    });
}

// this function is used to get photo data 
function fetchPhoto(data){
    nrequest = data.photos.photo.length; // the number of requested photo 
    nrecived = 0; // how many are recieved actually
    for (let i = 0; i < data.photos.photo.length; i++){ // iterate through data
        let photoObj = {id: data.photos.photo[i].id, title: data.photos.photo[i].title};
        photos.push(photoObj); // add it to photos collection
        getSizes(photoObj); // in order to display it get the sizes of this photo
    }
}

// this function is used to get different sizes of this photo in order to display
function getSizes(photoObj){
    var file ="";
    var fullFile = "";
    let getSizesStr = "https://api.flickr.com/services/rest/?method=flickr.photos.getSizes&format=json&nojsoncallback=1&" + API_KEY + "&photo_id=" + photoObj.id;
    $.get(getSizesStr, function(data){
        nrecived++;
        // to make sure there is source that avaliable 
        for (var i=0; i< data.sizes.size.length; i++) {
            if (data.sizes.size[i].label == "Small") {
                file = data.sizes.size[i].source;
            }
            if (data.sizes.size[i].label == "Medium") {
                file = data.sizes.size[i].source;
            }
            if (data.sizes.size[i].label == "Medium") {
                fullFile = data.sizes.size[i].source;
            }
            if (data.sizes.size[i].label == "Large") {
                fullFile = data.sizes.size[i].source;
            }
        }
        
        photoObj.file = file; // add a porperty
        photoObj.full = fullFile;// add a porperty
        
        if (photoObj.file !== "" && photoObj.full !== "") { // if this photo could be displayed
            ready_cd(photos); // display it
        }
        
    });
}

// this is search function 
export function display_search(input){
    let resultStr = "https://api.flickr.com/services/rest/?method=flickr.photos.search&format=json&nojsoncallback=1&" + API_KEY + "&text=" + input;
    $.get(resultStr, function(data){ // fetch photo data
        nrequest = data.photos.photo.length;
        for (let i = 0; i < 10; i++){ // iterate through
            let photoObj = {id: data.photos.photo[i].id, title: data.photos.photo[i].title};
            photos.push(photoObj); // add to photos collection
            getSizes(photoObj); // get sizes of it
        }
    });
}
