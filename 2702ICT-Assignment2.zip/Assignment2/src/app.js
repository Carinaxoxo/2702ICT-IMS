import $ from "jquery";
import styles from "./css/styles.css";
import * as view from "./view.js";
import * as flickr from "./flickr.js";
import * as facebook from "./facebook.js";
import * as google from "./google.js";
import alertphoto from "./assets/alertimg.png";
import  alerts from "./templates/alert.handlebars";

let photo = {
    photos: [
        {src: alertphoto, title: "alert"}
    ]
}; //prepare for showing alert photo
let indexs = []; //make a list to track the index of the photo that the user is viewing

// this function is called when the page is ready
$(document).ready(function(){
    flickr.getInteresting(flickrReady); //retrieve photos from flikr then to be displayed
    facebook.boost(informationReady); // show the button used for users to login
    google.initMap(); //create a map
    showAlert(photo); //show the alert photo
    
    // this function is called to search photos from flickr
    $("#search-btn").click(function() {
        flickr.display_search($("#search-input").val()); //call the search funtion and pass the value to be searched 
    });
    
    // this function is called to view last photo
    $('#modal-left').click(function() { // get to last photo
        $("#interesting figure").eq(indexs[indexs.length - 1] - 1).click();
    });
    
    // this function is used to view next photo
    $('#modal-right').click(function() { // get to next photo
        $("#interesting figure").eq(indexs[indexs.length - 1] + 1).click();
    });
    
    // this function is used to close full-photo viewing 
    $('#modal-close').click(function(){
        $('#modal-container').css('display', 'none');
        $('#modal-content').attr('src', ''); // clear the src attribute
    });
    
});

// Since we use Webpack , when defining function in controller to be called by the login button we need to be defined it under
//the window object so it can be accessed via HTML
window.loggedin = function() {
    // Get the user object of the current logged in user:
    FB.api('/me?fields=id,name,hometown,location,events{place},likes{location}', function(response) {
        facebook.receive(response); // pass the value to facebook to rearrange the data then use it
        if (response.name) { // if a user is logged in
            $("header").html(`Let's shake photos with ${response.name}`); // welcome this user by printing the name on the header
        } else { // if no one is logged in
            $("header").html(`Let's shake with photos`); //display the regular header
        }
    }, {scope:'user_posts, user_location, user_posts, user_events'});// declear the permissions will be used 
}

// display the alert photo
function showAlert(data) {
    $("#alert").html(alerts(photo));
}

// this function is used for passing value
// used whenflickr function is already finished
export function flickrReady(data) {
    view.displayIntres(data); //pass value to view
    registerModal(data); //enable gull-photo viewing
}

// when information is collect call this function to pass value to view
function informationReady(data) {
    view.displayInfo(data);
}

// this function is used to enable full-photo viewing
function registerModal(data) {
    var titles = []; // to collect titles
    for (var i=0; i< data.length; i++) { // get titles
        titles.push(data[i].title);
    }
    $('figure').each(function(index) { // when a figure is clicked, execute this function
        $(this).click(function() { // when a figure is clicked, execute this function
            $('#modal-container').css('display', 'block'); // make the full page displayed
            $('#modal-content').attr('src', $(this).attr('data-full')); // display the full photo
            $("#modal-caption").html(titles[index]);  // display its tile
            
            indexs.push(index); // used to make sure which photo is being viewed
        });
    });
}