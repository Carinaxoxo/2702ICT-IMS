import $ from "jquery";
import * as flickr from "./flickr.js";
const APP_ID = "2696756133671994";

let ready_dp;
let events = [];
let locations = [];
let likes = [];
let info = [];

export function boost(ready) {
  ready_dp = ready; //this is a function used to pass data to view
  
  // used to enable facebook login button
  $.ajaxSetup({ cache: true });
  $.getScript('https://connect.facebook.net/en_US/sdk.js', function(){
    FB.init({
      appId: APP_ID,
      version: 'v2.7', // or v2.1, v2.2, v2.3, ...
      xfbml: 1
    });
  });
}

// this function is used to rearrange data to make it readable by google and to be displayed 
export function receive(response) {
  if (response.location) { // if there is location info
    let locObj = {id: response.location.id, location: response.location.name}; // write it down in the object to store location info
      locations.push(locObj); // add 
    info.push(locations); // finally add to info object
  }
  
  if (response.events) { //if this user liked some events
    for (var i=0; i < response.events.data.length; i++) {// write it down in the object to store events info
      let eventObj = {id: response.events.data[i].id, 
                      city: response.events.data[i].place.location.city, 
                      latitude: response.events.data[i].place.location.latitude, 
                      longitude: response.events.data[i].place.location.longitude};
      events.push(eventObj);
    }
    info.push(events);
  }
  
  if (response.likes) { // if this user liked some places
    for (var i=0; i < response.likes.data.length; i++) { // put the information in an object
      let likeObj = {id: response.likes.data[i].id, 
                     city: response.likes.data[i].location.city, 
                     latitude: response.likes.data[i].location.latitude, 
                     longitude: response.likes.data[i].location.longitude};
        likes.push(likeObj);
    }
  info.push(likes);
  }
  
  //all the info is collected in the info object
  ready_dp(info); // pass this object to display them
}
