import $ from "jquery";
import * as flickr from "./flickr.js";

var map;

// this function is used to create a map
export function initMap() {
  var myLatlng = {lat: -25.363, lng: 131.044}; // to populate info for a center
  
  // create a  blank map
  map = new google.maps.Map(document.getElementById('map'), { 
    zoom: 4,
    center: myLatlng //make sure the center
  });
  
  // create a marker
  var marker = new google.maps.Marker({ 
    position: myLatlng,
    map: map,
    title: 'Click to zoom'
  }); 
  
}

// this function is for adding markers of placed interested by logged in user
export function AddLocMarkers(info) {
  for (var i = 0; i < info.events.length; i++) { // go through info about events
    var marker = new google.maps.Marker({
      position: { // add position info
        lat: info.events[i].latitude,
        lng: info.events[i].longitude,
      },
      map: map, // to tell which map to add a marker 
      title: info.events[i].city // add a title for getting location info
    });
    attachSecretMessage(marker, info.events[i].city); // add a message to be displayed when click
    
    marker.addListener('click', function() { // like a click function
      flickr.display_search(marker.getTitle()); // search photos of this place
      map.setZoom(8); // zoom
      map.setCenter(marker.getPosition()); // change center
    });
  }
  
  // this works the same way as last for loop but to get info about likes
  for (var i = 0; i < info.likes.length; i++) {
    var marker = new google.maps.Marker({
      position: {
        lat: info.likes[i].latitude,
        lng: info.likes[i].longitude,
      },
      map: map,
      title: info.likes[i].city
    });
    attachSecretMessage(marker, info.likes[i].city);
    
    marker.addListener('click', function() {
      flickr.display_search(marker.getTitle());
      map.setZoom(8);
      map.setCenter(marker.getPosition());
    });
  }
}

// Attaches an info window to a marker with the provided message. When the
// marker is clicked, the info window will open with the secret message.
function attachSecretMessage(marker, city) {
  var infowindow = new google.maps.InfoWindow({
    content: city // add the secret message
  });

  marker.addListener('click', function() {
    infowindow.open(marker.get('map'), marker);
  });
}